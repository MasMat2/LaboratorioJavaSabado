package practica9i;

public interface DispositivoElectronico {
    public abstract String encender();

    public abstract String apagar();
}