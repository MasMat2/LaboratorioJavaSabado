package practica10i;

public interface DispositivoElectronico {
    public abstract String encender();

    public abstract String apagar();
}